## Installation Guide

1. Open _utilities.f90_, search __Your path__ and modify __LibF__ with the location of this file in your machine.
2. Launch a terminal window and change directories to the same directory.
3. Execute the installation program by entering the following command.
```bash
make
```
4. Add this directory to your PATH environment variable (e.g. in _.bashrc_)
5. Check the Python dependencies. Make sure that you have the following packages in your Python environment:
	- numpy
	- astropy
	- h5py
6. [Optional] Run the test.
```bash
python test_synphot.py
```
7. To uninstall, just run 
```bash
make mrproper
```

## User Manual

- Import synphot
- Input filters (one or several) and spectral data (wavelengths and spectra)
- __tmpdir__ define the directory (default is cwd) to store i/o data when __verbose__ is set True
- The output has following attributes:
	- __wcen__: photometry wavelength
	- __Fnu_filt__: synthetic photometry
	- __smat__: standard deviation
- Example
```python
from synphot import synthetic_photometry

filters = 'IRAC4', 'MIPS1'
output = synthetic_photometry(filters, wavelength, spectra)
for i in len(filters):
	print(filters[i]+' wavelength: ', output.wcen[i])
	print(filters[i]+'syn phot: ', output.Fnu_filt[i])
	print(filters[i]+'syn phot unc: ', output.smat[i][i])
```

## Notice

This package is extracted from F. Galliano's _SwING_ library which is not yet published. D. Hu contributed to the Python interface.

Please report any bug or advices to dangning.hu@cea.fr
