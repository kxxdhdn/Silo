#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""

SYNTHETIC PHOTOMETRY

"""

import os
import numpy as np
from astropy.io import fits
# import matplotlib.pyplot as plt

from synphot import synthetic_photometry

## Path
##------
curfildir = os.path.dirname(os.path.abspath(__file__))
datdir = curfildir+'/tests/dat/'
outdir = curfildir+'/tests/out/'

## Read spec data
##----------------
with fits.open(datdir+'M82.fits') as hdul:
	hdr = hdul[0].header
	spec = hdul[0].data
	wave = hdul[1].data
## Extrapolate the wavelengths that are not covered
wave[0] = .1
spec[:2] = 0

## Do synthetic photometry
##-------------------------
phot = 'IRAC4'
output = synthetic_photometry(phot, wave, spec)
print(phot+' wavelength: ', output.wcen[0])
print('Uncertainty: ', output.smat[0][0])

## Synthetic photometry map
##--------------------------
# plt.imshow(output.Fnu_filt[0])
# plt.show()
