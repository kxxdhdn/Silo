#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""

SYNTHETIC PHOTOMETRY

"""

import os
import numpy as np
import h5py as H5
h5ext = '.h5'
import subprocess as SP

def read_hdf5(file, *header):
	'''
	Read h5 file

	------ INPUT ------
	file                input h5 file
	header              labels of data to read
	------ OUTPUT ------
	dataset             data
	'''
	hf = H5.File(file+h5ext, 'r')
	dataset = []
	for hdr in header:
		data = hf.get(hdr)
		data = np.array(data)
		dataset.append(data)

	hf.close()

	return dataset

def write_hdf5(file, header, data, append=False):
	'''
	Write h5 file

	------ INPUT ------
	file                file name of the new h5 file
	header              label of data (one at a time)
	data                data
	append              True: if not overwrite (default: False)
	------ OUTPUT ------
	'''
	if append==True:
		hf = H5.File(file+h5ext, 'a')
	else:
		hf = H5.File(file+h5ext, 'w')
	
	hf.create_dataset(header, data=data)

	hf.flush()
	hf.close()

def synthetic_photometry(filt_UTF8, w_spec=None, Fnu_spec=None, 
	tmpdir=None, verbose=False):
	'''
	This is the Python interface, 
	the functional code is in Fortran.

	------ INPUT ------
	filt_UTF8           photometry name (tuple or list)
	w_spec              wavelengths (1darray)
	Fnu_spec            spectra (ndarray)
	tmpdir              path of temporary files (Default: cwd)
	verbose             keep tmp files (Default: False)
	------ OUTPUT ------
	cl                  output object
	  wcen              center wavelength
	  Fnu_filt          synthetic photometry
	  smat              standard deviation matrices
	'''
	cl = type('', (), {})()

	if tmpdir is None:
		tmpdir = os.getcwd()+'/'

	## Input filter can be: 
	## a single string, a tuple or a list
	if isinstance(filt_UTF8, str):
		filt_UTF8 = [filt_UTF8]
	else:
		filt_UTF8 = list(filt_UTF8)

	## Write the input file
	##----------------------
	fortIN = tmpdir+'synthetic_photometry_input'

	filt_ASCII = [n.encode('ascii', 'ignore') for n in filt_UTF8]
	write_hdf5(fortIN, 'Filter label', filt_ASCII)
	write_hdf5(fortIN, 'Wavelength (microns)', w_spec, append=True)
	write_hdf5(fortIN, 'Flux (x.Hz-1)', Fnu_spec, append=True)
	write_hdf5(fortIN, '(docalib,dophot)', [1,1], append=True)

	## Call the Fortran lib
	##----------------------
	SP.call('synthetic_photometry', shell=True)

	## Read the output
	##-----------------
	fortOUT = tmpdir+'synthetic_photometry_output'

	cl.wcen, cl.Fnu_filt, cl.smat = read_hdf5(fortOUT, \
		'Central wavelength (microns)', \
		'Flux (x.Hz-1)', \
		'Standard deviation matrix')

	## Convert zeros to NaNs
	ma_zero = np.ma.array(cl.Fnu_filt, mask=(cl.Fnu_filt==0)).mask
	cl.Fnu_filt[ma_zero] = np.nan

	## Clean temperary file
	##----------------------
	if verbose==False:
		SP.call('rm -rf '+fortIN+'.h5', \
			shell=True, cwd=tmpdir)
		SP.call('rm -rf '+fortOUT+'.h5', \
			shell=True, cwd=tmpdir)

	return cl

"""
------------------------------ MAIN (test) ------------------------------
"""
if __name__ == "__main__":

	pass
