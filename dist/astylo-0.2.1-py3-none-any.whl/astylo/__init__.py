#!/usr/bin/env python
#-*- coding:utf-8 -*-


print("---------------------------------------------\n")
print("           -=-=-=-=-=-=-=-=-=-")
print("          |       astylo      |")
print("           -=-=-=-=-=-=-=-=-=-")
print("\n            Author: D. HU")
print("          Version 0.2.1 (20200417)")
print("\n---------------------------------------------")


import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def iTest():
	'''
	Initial test of astylo
	'''
	print("\nHouston, Tranquility Base here. The Eagle has landed.\n")

if __name__ == '__main__':
    
    iTest()
